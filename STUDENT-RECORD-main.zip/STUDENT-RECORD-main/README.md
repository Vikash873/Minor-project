# STUDENT-RECORD
A comprehensive MongoDB/Mongoose-based Student Record Management System designed for educational institutions to efficiently store, manage, and validate student information.
